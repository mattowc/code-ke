<?php
/*
Plugin Name:  OWC Butler
Plugin URI:  http://onewebcentric.com
Description:  Adds some useful shortcode to WordPress
Version:  .01
Author URI:  http://onewebcentric.com
Author:  Jon McDonald of OneWebCentric
*/

/*
 * Define our plugin path
 */
define( 'OWC_PATH', plugin_dir_path(__FILE__) );

//Includes code to create sliders
include_once( OWC_PATH . '/slider.php');


?>